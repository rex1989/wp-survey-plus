=== WP Survey Plus ===
License: GPL v3
Tags: survey, form builder, survey form, data collection, feedback, free, plugin, polls, questionaire, poll builder, opinion, customer satisfaction
Requires at least: 3.0
Tested up to: 4.0
Stable tag: 1.0

== Description ==

This plugin allows you to create surveys, collect responces and export result in csv powered by 100% ajax functionality which runs 200% faster.


Features :

* create unlimitel surveys
* single or multiple answer
* assign different surveys to pages/posts
* open surveys in colorbox
* 100% ajax functionality works 200% faster
* 100% responsive design
* view reports on backend
* export survey details in csv with user emails
* responsive survey button to encorage visitors to take survey
* localizable

Translations :

* English (default by Pradeep)

== Installation ==

This plugin is almost plug and play! Just activate it and then go to Surveys menu. You will learn automatically.

* create surveys
* assign survey to any page/post by selecting survey on edit of repective page/post
* happy surveys!!!

== Screenshots ==

1. screenshot-1.jpg
2. screenshot-2.jpg
3. screenshot-3.jpg
4. screenshot-4.jpg
5. screenshot-5.jpg
6. screenshot-6.jpg
7. screenshot-7.jpg
8. screenshot-8.jpg
9. screenshot-9.jpg
10. screenshot-10.jpg

== Changelog ==

= V 1.0 =
* Initial release.
