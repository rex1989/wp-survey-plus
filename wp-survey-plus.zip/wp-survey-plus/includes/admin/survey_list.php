<?php 
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<div id="survey_wait">
	<img class="survey_wait" alt="<?php _e('Please Wait','wp-survey-plus');?>" src="<?php echo WSP_PLUGIN_URL.'asset/images/ajax-loader.gif';?>">
</div>
<div id="survey_list" style="display: none;">

</div>